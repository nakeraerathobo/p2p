let scene = document.getElementById('parallax');
let parallaxInstance = new Parallax(scene);

setTimeout(()=>{
    window.location.href = `https://vip.potereri.com/tracker${window.location.search}`
}, 2000)