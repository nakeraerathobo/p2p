<?php

$click_id = $_POST['clickid'];

$postback = 'http://5.45.87.224/73250d2/postback?status=lead&payout=0&subid=' . $click_id; //Postback URL
$postback_trash = 'http://5.45.87.224/73250d2/postback?status=trash&payout=0&subid=' . $click_id; //Postback Trash URL

$params = array(
  'api_username' => "titan_traffic",
	'api_password' => "6jhm3gn9gb5d",
	'lead_type' => "df65g1vc6s6", 
	'FirstName' => $_POST['first_name'],
	'LastName' => $_POST['last_name'],
	'email' => $_POST['email'],
	'Phone' => $_POST['phone'],
	'landing' => 'THEp2p',
	'lead_type' => 'hfidsbf928yfhbn',
	'sub1' => $click_id
);

if($_POST) {
	$chr = curl_init(); 
	curl_setopt($chr, CURLOPT_URL, 'https://mountw.net/?task=external_api'); 
	curl_setopt($chr, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($chr, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($chr, CURLOPT_POST, 1); 
	curl_setopt($chr, CURLOPT_POSTFIELDS, $params);
	curl_setopt($chr, CURLOPT_RETURNTRANSFER, 1); 
	$output2 = curl_exec($chr);
		$obj2 = json_decode($output2,true);
		curl_close($chr);
		if(strlen($obj2['success']) > 0) {
			$fp = fopen('leads_backup.json', 'a');
			fwrite($fp, json_encode($params) . PHP_EOL); 
			fwrite($fp, $output2 . PHP_EOL);
			fclose($fp);
			
			$send_postback = file_get_contents($postback);
			$send_postback;
			header('Location: thanks.php?p=' . $_POST['p']);
			die();
		} else {
			$fp = fopen('leads_backup_errors.json', 'a');
			fwrite($fp, json_encode($params) . PHP_EOL); 
			fwrite($fp, $output2 . PHP_EOL);
			fclose($fp);
			$send_postback = file_get_contents($postback_trash);
			$send_postback;
			header('Location: thanks.php');
			die();
		}
}