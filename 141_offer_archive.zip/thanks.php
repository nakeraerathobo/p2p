<!DOCTYPE html>
<html lang="ru">
	<head>
		<title>Счет создан. Добро пожаловать!</title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="stylesheet" href="thx/thx.css">
		<link rel="apple-touch-icon" sizes="76x76" href="apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/parallax/3.1.0/parallax.min.js"></script>



	</head>
	<body>
		<div class="thx">
			<div class="thx__container">
				<div class="thx__box">
					<div class="thx-right">
						<div id="parallax">
							<div data-depth="0.2" class="thx-right__item-1">
								<img src="thx/1.png" alt="Congrats item">
							</div>
							<div data-depth="0.3" class="thx-right__item-2">
								<img src="thx/2.png" alt="Congrats item">
							</div>
							<div data-depth="0.4" class="thx-right__item-2">
								<img src="thx/3.png" alt="Congrats item">
							</div>
						</div>
					</div>
					<div class="thx-left">
						<h2 class="thx-left__title">Счет создан. Добро пожаловать!</h2>
						<p class="thx-left__text">
						<h2 class="thx-left__title">
						Вы получите либо подтверждение по электронной почте, либо телефонный звонок с дальнейшими инструкциями... </h2
						</p>
					</div>
				</div>
			</div>
		</div>
		<script>
			let scene = document.getElementById('parallax');
			let parallaxInstance = new Parallax(scene);
		</script>
		<?php
			if(strlen($_COOKIE['cabinet']) > 0) {
				header("refresh: 3; url = ".$_COOKIE['cabinet']);
			}
			?>
			
		<!-- FB Pixel -->
		<?php if($_GET['p']) {?>
		<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo $_GET['p'] ?>&ev=Lead&noscript=1"/>
		<?php } ?>
		<!-- FB Pixel -->
	</body>
</html>