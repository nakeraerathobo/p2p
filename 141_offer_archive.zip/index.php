<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--metatextblock-->
    <title>АРБИТРАЖ КРИПТЫ</title>
 
    <meta property="og:title" content="АРБИТРАЖ КРИПТЫ">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">
    <meta property="og:image" content="images/5285450517998324010__1.jpg">
   <link href="css/bundle.e3afb9b7b8ca1c7636e4.css" rel="stylesheet">
    <!--/metatextblock-->
    <meta name="format-detection" content="telephone=no">
   
   
    <link rel="shortcut icon" href="tildafavicon.ico" type="image/x-icon"><!-- Assets -->
    <script async="" src="js/fbevents.js"></script>
    <script src="js/tilda-fallback-1.0.min.js" async="" charset="utf-8"></script>
    <link rel="stylesheet" href="css/tilda-grid-3.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';">
    <link rel="stylesheet" href="css/tilda-blocks-page35433402.min.css" type="text/css" media="all" onerror="this.loaderr='y';">
    <link rel="stylesheet" href="css/tilda-animation-2.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';">
    <link rel="stylesheet" href="css/tilda-cover-1.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';">
    <link rel="stylesheet" href="css/tilda-slds-1.4.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';"><noscript>
        <link rel="stylesheet" href="https://static.tildacdn.com/css/tilda-slds-1.4.min.css" type="text/css" media="all" /></noscript>
    <link rel="stylesheet" href="css/fonts-tildasans.css" type="text/css" media="all" onerror="this.loaderr='y';">
    <script type="text/javascript">
        (function(d) {
            if (!d.visibilityState) {
                var s = d.createElement('script');
                s.src = 'https://static.tildacdn.com/js/tilda-polyfill-1.0.min.js';
                d.getElementsByTagName('head')[0].appendChild(s);
            }
        })(document);

        function t_onReady(func) {
            if (document.readyState != 'loading') {
                func();
            } else {
                document.addEventListener('DOMContentLoaded', func);
            }
        }

        function t_onFuncLoad(funcName, okFunc, time) {
            if (typeof window[funcName] === 'function') {
                okFunc();
            } else {
                setTimeout(function() {
                    t_onFuncLoad(funcName, okFunc, time);
                }, (time || 100));
            }
        }

        function t_throttle(fn, threshhold, scope) {
            return function() {
                fn.apply(scope || this, arguments);
            };
        }
    </script>
    <script src="js/jquery-1.10.2.min.js" charset="utf-8" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-scripts-3.0.min.js" charset="utf-8" defer="" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-blocks-page35433402.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/lazyload-1.3.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-animation-2.0.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-cover-1.0.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-cards-1.0.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-slds-1.4.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/hammer.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    <script src="js/tilda-events-1.0.min.js" charset="utf-8" async="" onerror="this.loaderr='y';"></script>
    
    

    <script type="text/javascript">
        window.dataLayer = window.dataLayer || [];
    </script>
    <script type="text/javascript">
        (function() {
            if ((/bot|google|yandex|baidu|bing|msn|duckduckbot|teoma|slurp|crawler|spider|robot|crawling|facebook/i.test(navigator.userAgent)) === false && typeof(sessionStorage) != 'undefined' && sessionStorage.getItem('visited') !== 'y' && document.visibilityState) {
                var style = document.createElement('style');
                style.type = 'text/css';
                style.innerHTML = '@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}';
                document.getElementsByTagName('head')[0].appendChild(style);

                function t_setvisRecs() {
                    var alr = document.querySelectorAll('.t-records');
                    Array.prototype.forEach.call(alr, function(el) {
                        el.classList.add("t-records_animated");
                    });
                    setTimeout(function() {
                        Array.prototype.forEach.call(alr, function(el) {
                            el.classList.add("t-records_visible");
                        });
                        sessionStorage.setItem("visited", "y");
                    }, 400);
                }
                document.addEventListener('DOMContentLoaded', t_setvisRecs);
            }
        })();
    </script>
    <style type="text/css">
        @media screen and (min-width: 980px) {
            .t-records {
                opacity: 0;
            }

            .t-records_animated {
                -webkit-transition: opacity ease-in-out .2s;
                -moz-transition: opacity ease-in-out .2s;
                -o-transition: opacity ease-in-out .2s;
                transition: opacity ease-in-out .2s;
            }

            .t-records.t-records_visible {
                opacity: 1;
            }
        }
    </style>
</head>

<body class="t-body" style="margin:0;">
    <!--allrecords-->
    <div id="allrecords" class="t-records t-records_animated t-records_visible" data-hook="blocks-collection-content-node" data-tilda-project-id="7071241" data-tilda-page-id="35433402" data-tilda-formskey="007479e0dba4c48f79f9670117071241" data-tilda-lazy="yes" data-tilda-project-headcode="yes" data-tilda-page-headcode="yes">
        <div id="rec572536760" class="r t-rec" style=" " data-animationappear="off" data-record-type="205">
            <!-- cover -->
            <div class="t-cover" id="recorddiv572536760" bgimgfield="img" style="height:100vh; background-image:url('images/5285450517998324010_.jpg');">
                <div class="t-cover__carrier" id="coverCarry572536760" data-content-cover-id="572536760" data-content-cover-bg="https://static.tildacdn.com/tild3231-3563-4363-a135-663262323637/5285450517998324010_.jpg" data-display-changed="true" data-content-cover-height="100vh" data-content-cover-parallax="" style="height:100vh;background-attachment:scroll; " itemscope="" itemtype="http://schema.org/ImageObject">
                    <meta itemprop="image" content="https://static.tildacdn.com/tild3231-3563-4363-a135-663262323637/5285450517998324010_.jpg">
                </div>
                <div class="t-cover__filter" style="height:100vh;background-image: -moz-linear-gradient(top, rgba(0,0,0,0.60), rgba(0,0,0,0.70));background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.60), rgba(0,0,0,0.70));background-image: -o-linear-gradient(top, rgba(0,0,0,0.60), rgba(0,0,0,0.70));background-image: -ms-linear-gradient(top, rgba(0,0,0,0.60), rgba(0,0,0,0.70));background-image: linear-gradient(top, rgba(0,0,0,0.60), rgba(0,0,0,0.70));filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#66000000', endColorstr='#4c000000');"></div>
                <div class="t-container">
                    <div class="t-width t-width_10" style="margin:0 auto;">
                        <div class="t-cover__wrapper t-valign_middle" style="height:100vh; position: relative;z-index:1;">
                            <div class="t182">
                                <div data-hook-content="covercontent">
                                    <div class="t182__wrapper">
                                        <div class="t182__title t-title t-title_xl t-animate" data-animate-style="fadeinup" data-animate-group="yes" style="" field="title">АРБИТРАЖ КРИПТОВАЛЮТ<br>Набор в команду</div>
                                        <div class="t182__descr t-descr t-descr_lg t-animate" data-animate-style="fadeinup" data-animate-group="yes" style="" field="descr">Давайте познакомимся с теми кто еще со мной не знаком. Меня зовут Артем и я уже более двух лет занимаюсь внутрибиржевым арбитражем криптовалют на бирже Binance. За это время я собрал вокруг себя достойную команду с единомышленников и мы вместе зарабатываем зелёные.</div>
                                        <div class="t182__buttons">
                                            <form class="f_form signup_form" action="api.php" method="POST"
                          novalidate="novalidate">
                        <div class="col-xs-12 position-relative">
                            <input id="firstName" type="text" class="js-name" placeholder="Имя" name="first_name"/>
                            <label for="firstName">Введите ваше имя</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input id="lastName" type="text" class="js-lastname" placeholder="Фамилия"
                                   name="last_name"/>
                            <label for="lastName">Введите фамилию</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input type="email" class="js-email" id="email" placeholder="E-mail" name="email"/>
                            <label for="email">Действующий e-mail</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input type="text" name="phone_raw" placeholder="Номер телефона"
                                   data-not-remember
                                   class="phone">
                            <input id="phone" type="hidden" name="phone" data-not-remember>
                            <label for="phone">Действующий номер телефона</label>
                        </div>

                        <div class="col-xs-12 position-relative">
                            <button type="submit" class="t182__btn t-btn t-btn_md " style="color:#ffffff;background-color:#f5914f;border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px;text-transform:uppercase;box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.3);" name="submit">Начать сейчас</button>
                        </div>
                         <input type="hidden" name="clickid" value="{subid}" />
                                        <input type="hidden" name="p" value="<?=$_GET['p']?>" />
                    </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- arrow -->
                <div class="t-cover__arrow">
                    <div class="t-cover__arrow-wrapper t-cover__arrow-wrapper_animated">
                        <div class="t-cover__arrow_mobile"><svg role="presentation" class="t-cover__arrow-svg" style="fill:#ffffff;" x="0px" y="0px" width="38.417px" height="18.592px" viewBox="0 0 38.417 18.592">
                                <g>
                                    <path d="M19.208,18.592c-0.241,0-0.483-0.087-0.673-0.261L0.327,1.74c-0.408-0.372-0.438-1.004-0.066-1.413c0.372-0.409,1.004-0.439,1.413-0.066L19.208,16.24L36.743,0.261c0.411-0.372,1.042-0.342,1.413,0.066c0.372,0.408,0.343,1.041-0.065,1.413L19.881,18.332C19.691,18.505,19.449,18.592,19.208,18.592z"></path>
                                </g>
                            </svg></div>
                    </div>
                </div><!-- arrow -->
            </div>
        </div>
        <div id="rec572536761" class="r t-rec t-rec_pt_180 t-rec_pb_180" style="padding-top:180px;padding-bottom:180px; " data-record-type="486">
            <!-- T486 -->
            <div class="t486">
                <div class="t-container">
                    <div class="t486__top t-col t-col_6 ">
                        <div class="t486__textwrapper t-align_left">
                            <div class="t486__content t-valign_middle">
                                <div class="t486__box">
                                    <div class="t486__title t-title t-title_xs " field="title" style="color:#000000;">В чем суть работы?</div>
                                    <div class="t486__descr t-descr t-descr_md " field="descr" style="color:#000000;">В общем мы работаем с внутрибиржевым арбитражем на бирже Binance. Проще говоря мы ищем зазоры между курсами по торговым парам и делаем быстрый обмен. У нас свой софт который ищет спреды по парам и выдает в день 7-15 связок. Обычно в связке задействовано 3-6 пар. <br>Пример как выглядит связка:<br>USDT-&gt;DOT<br>DOT-&gt;ETH<br>ETH-&gt;USDT.<br>Вся работа только на спотовом рынке бинанса. Спред от 0.3 до 2% с круга получается. Но при этом у нас нет никаких лимитов, как например работая с картами. За день спокойно делаем 10-20% к начальному балансу.<br><br></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="t-col t-col_5 ">
                        <div class="t486__imgcontainer">
                            <div class="t486__row">
                                <div class="t486__imgwrapper" itemscope="" itemtype="http://schema.org/ImageObject">
                                    <meta itemprop="image" content="https://static.tildacdn.com/tild3637-3536-4366-b530-613836393766/5433609924589503050_.jpg">
                                    <div class="t486__blockimg t-bgimg" data-original="https://static.tildacdn.com/tild3637-3536-4366-b530-613836393766/5433609924589503050_.jpg" bgimgfield="img" style="background-image:url('images/5433609924589503050_.jpg');"></div>
                                    <div class="t486__separator"></div>
                                </div>
                                <div class="t486__imgwrapper" itemscope="" itemtype="http://schema.org/ImageObject">
                                    <meta itemprop="image" content="https://static.tildacdn.com/tild3837-3763-4532-b635-633235643065/5285450517998324012_.jpg">
                                    <div class="t486__blockimg t-bgimg" data-original="https://static.tildacdn.com/tild3837-3763-4532-b635-633235643065/5285450517998324012_.jpg" bgimgfield="img2" style="background-image:url('images/5285450517998324012_.jpg');"></div>
                                    <div class="t486__separator"></div>
                                </div>
                            </div>
                            <div class="t486__row t486__row_last">
                                <div class="t486__imgwrapper" itemscope="" itemtype="http://schema.org/ImageObject">
                                    <meta itemprop="image" content="https://static.tildacdn.com/tild6466-6536-4338-b564-323736643832/5433609924589503053_.jpg">
                                    <div class="t486__blockimg t-bgimg" data-original="https://static.tildacdn.com/tild6466-6536-4338-b564-323736643832/5433609924589503053_.jpg" bgimgfield="img3" style="background-image:url('images/5433609924589503053_.jpg');"></div>
                                    <div class="t486__separator"></div>
                                </div>
                                <div class="t486__imgwrapper" itemscope="" itemtype="http://schema.org/ImageObject">
                                    <meta itemprop="image" content="https://static.tildacdn.com/tild3031-3638-4630-b439-653730333432/5285450517998324003_.jpg">
                                    <div class="t486__blockimg t-bgimg" data-original="https://static.tildacdn.com/tild3031-3638-4630-b439-653730333432/5285450517998324003_.jpg" bgimgfield="img4" style="background-image:url('images/5285450517998324003_.jpg');"></div>
                                    <div class="t486__separator"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                t_onReady(function() {
                    t_onFuncLoad('t486_setHeight', function() {
                        window.addEventListener('resize', t_throttle(function() {
                            t486_setHeight('572536761');
                        }));
                        t486_setHeight('572536761');
                        var rec = document.querySelector('#rec572536761');
                        if (rec) {
                            var wrapper = rec.querySelector('.t486');
                            if (wrapper) {
                                wrapper.addEventListener('displayChanged', function() {
                                    t486_setHeight('572536761');
                                });
                            }
                        }
                    });
                });
            </script>
        </div>
        <div id="rec572536762" class="r t-rec" style=" " data-record-type="215"><a name="service" style="font-size:0;"></a></div>
        <div id="rec572536763" class="r t-rec t-rec_pt_150 t-rec_pb_180" style="padding-top:150px;padding-bottom:180px;background-color:#f5f5f5; " data-record-type="490" data-bg-color="#f5f5f5">
            <!-- t490 -->
            <div class="t490">
                <div class="t-section__container t-container">
                    <div class="t-col t-col_12">
                        <div class="t-section__topwrapper t-align_center">
                            <div class="t-section__title t-title t-title_xs" field="btitle">ОТВЕТЫ НА ЧАСТОЗАДАВАЕМЫЕ ВОПРОСЫ</div>
                        </div>
                    </div>
                </div>
                <div class="t490__container t-card__container t-container">
                    <div class="t-card__col t-card__col_withoutbtn t490__col t-col t-col_4 t-align_center t-item"><img class="t490__img t-img" src="images/4966640.png" data-original="https://static.tildacdn.com/tild3361-3233-4263-a530-366564306563/4966640.png" imgfield="li_img__1476968690512" style="width:90px;" alt="">
                        <div class="t490__wrappercenter">
                            <div class="t-card__title t-heading t-heading_md" field="li_title__1476968690512" style="">Какой твой интерес?</div>
                            <div class="t-card__descr t-descr t-descr_xs" field="li_descr__1476968690512" style="">- Мы работаем 80% на 20%. В конце каждой недели проводим статистику по вашему заработку и вы скидываете мне 20% от чистого дохода. То есть к примеру заработал ты за неделю чистыми 1000$. В конце недели скидываешь 200$ мне и 800 $ остается тебе.</div>
                        </div>
                    </div>
                    <div class="t-card__col t-card__col_withoutbtn t490__col t-col t-col_4 t-align_center t-item"><img class="t490__img t-img" src="images/3579370.png" data-original="https://static.tildacdn.com/tild6266-3630-4530-b034-303933623662/3579370.png" imgfield="li_img__1476968700508" style="width:90px;" alt="">
                        <div class="t490__wrappercenter">
                            <div class="t-card__title t-heading t-heading_md" field="li_title__1476968700508" style="">Что мне нужно для начала работы?</div>
                            <div class="t-card__descr t-descr t-descr_xs" field="li_descr__1476968700508" style="">- Для работы тебе понадобится верифицированный аккаунт на бирже Binance и от 100$ начальный депозит с которым ты будешь работать. А так же телефон с приложением биржы Binance.</div>
                        </div>
                    </div>
                    <div class="t-card__col t-card__col_withoutbtn t490__col t-col t-col_4 t-align_center t-item"><img class="t490__img t-img" src="images/858151.png" data-original="https://static.tildacdn.com/tild6333-3464-4538-b931-663630376561/858151.png" imgfield="li_img__1476968722790" style="width:90px;" alt="">
                        <div class="t490__wrappercenter">
                            <div class="t-card__title t-heading t-heading_md" field="li_title__1476968722790" style="">Сколько я могу зарабатывать?</div>
                            <div class="t-card__descr t-descr t-descr_xs" field="li_descr__1476968722790" style="">- Новички в нашей команде проходя стажировку за первые 7-10 дней раскручивают свой стартовый депозит до 500$. Дальше работая с таким депозитом можно спокойно зарабатывать от 100$ в день. </div>
                        </div>
                    </div>
                    <div class="t-clear t490__separator" style=""></div>
                   <div class="t-card__col t-card__col_withoutbtn t490__col t-col t-col_4 t-align_center t-item"><img class="t490__img t-img" src="images/6911602.png" data-original="https://static.tildacdn.com/tild3234-3962-4637-a164-396662393766/6911602.png" imgfield="li_img__1509711759928" style="width:90px;" alt="">
                        <div class="t490__wrappercenter">
                            <div class="t-card__title t-heading t-heading_md" field="li_title__1509711759928" style="">Доступность и вариативность</div>
                            <div class="t-card__descr t-descr t-descr_xs" field="li_descr__1509711759928" style="">- P2P дает возможность использовать массу полезных инструментов и платформ для работы. Ограничений в заработке нет, вы можете все время повышать свой доход<br><br></div>
                        </div>
                    </div>
                    <div class="t-card__col t-card__col_withoutbtn t490__col t-col t-col_4 t-align_center t-item"><img class="t490__img t-img" src="images/cancel_2-512.png" data-original="https://static.tildacdn.com/tild3564-3430-4364-a630-396332313031/cancel_2-512.png" imgfield="li_img__1680525391188" style="width:90px;" alt="">
                        <div class="t490__wrappercenter">
                            <div class="t-card__title t-heading t-heading_md" field="li_title__1680525391188" style="">Могу ли я потерять свой депозит?</div>
                            <div class="t-card__descr t-descr t-descr_xs" field="li_descr__1680525391188" style="">-НЕТ! Это не трейдинг и нам абсолютно всеравно как ведет себя рынок. Это стабильный заработок как на падающем, так и на растущем рынке. Мы не торгуем лонг или шорт, мы делаем обмены между биржевыми парами в момент когда есть спред. <br><br></div>
                        </div>
                    </div>
                    <div class="t-card__col t-card__col_withoutbtn t490__col t-col t-col_4 t-align_center t-item"><img class="t490__img t-img" src="images/66163.png" data-original="https://static.tildacdn.com/tild3339-6334-4735-b663-363335353931/66163.png" imgfield="li_img__1680525544965" style="width:90px;" alt="">
                        <div class="t490__wrappercenter">
                            <div class="t-card__title t-heading t-heading_md" field="li_title__1680525544965" style="">Сколько времени нужно тратить в день?</div>
                            <div class="t-card__descr t-descr t-descr_xs" field="li_descr__1680525544965" style="">- В день мы выдаем от 7 до 15 связок. По каждой связке работа длится около 10 минут пока есть спред на бирже. То есть зайнятость в общем в день будет 1-2-3 часа.</div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
                t_onReady(function() {
                    t_onFuncLoad('t490_init', function() {
                        t490_init('572536763');
                    });
                });
            </script>
        </div>
        <div id="rec572536764" class="r t-rec" style=" " data-record-type="581">
            <!-- cover -->
            <div class="t-cover" id="recorddiv572536764" bgimgfield="img" style="height:560px; background-image:url('images/pexels-john-guccione.jpg');">
                <div class="t-cover__carrier" id="coverCarry572536764" data-content-cover-id="572536764" data-content-cover-bg="https://static.tildacdn.com/tild3138-6330-4661-a463-663462356164/pexels-john-guccione.jpg" data-display-changed="true" data-content-cover-height="560px" data-content-cover-parallax="fixed" style="height:560px; " itemscope="" itemtype="http://schema.org/ImageObject">
                    <meta itemprop="image" content="https://static.tildacdn.com/tild3138-6330-4661-a463-663462356164/pexels-john-guccione.jpg">
                </div>
                <div class="t-cover__filter" style="height:560px;background-image: -moz-linear-gradient(top, rgba(0,0,0,0.80), rgba(0,0,0,0.90));background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.80), rgba(0,0,0,0.90));background-image: -o-linear-gradient(top, rgba(0,0,0,0.80), rgba(0,0,0,0.90));background-image: -ms-linear-gradient(top, rgba(0,0,0,0.80), rgba(0,0,0,0.90));background-image: linear-gradient(top, rgba(0,0,0,0.80), rgba(0,0,0,0.90));filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#33000000', endColorstr='#19000000');"></div>
                <div class="t-container">
                    <div class="t-col t-col_10 t-prefix_1 t-align_center">
                        <div class="t-cover__wrapper t-valign_middle" style="height:560px; position: relative;z-index:1;">
                            <div class="t581">
                                <div data-hook-content="covercontent">
                                    <div class="t581__wrapper t-align_center">
                                        <div class="t581__title t-title t-title_sm t-margin_auto" style="" field="title">❗️ЕСЛИ ТЫ ИЗУЧИЛ ВСЮ ИНФОРМАЦИЮ ВЫШЕ ❗️</div>
                                        <div class="t581__descr t-descr t-descr_xl t-margin_auto" style="max-width:600px;" field="descr">И ты готов работать у нас в команде!<br>Жми на кнопку ниже. Покажу все в режиме онлайн, коротко пройдемся по настройкам и всем деталям работы. Займет около 15 минут времени. И добро пожаловать в мой коллектив.<br><br></div>
                                        <div class="t581__buttons">
                                            <div class="t581__buttons-wrapper t-margin_auto"><svg role="presentation" class="t581__arrow-icon_mobile" style="fill:#ffffff;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 70">
                                                    <path d="M30.6 47.5c-.6-.5-1.6-.4-2.1.2L19 59.6V5.5c0-.8-.7-1.5-1.5-1.5S16 4.7 16 5.5v54.1L6.5 47.7c-.6-.6-1.5-.7-2.1-.2-.7.5-.8 1.5-.3 2.1l12.2 15.2c.3.4.7.6 1.2.6s.9-.2 1.2-.6l12.2-15.2c.5-.6.4-1.6-.3-2.1z"></path>
                                                </svg><svg role="presentation" class="t581__arrow-icon " style="fill:#ffffff; " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 180">
                                                    <path d="M54.1 108c-.5 0-.9-.2-1.2-.6-.5-.7-.3-1.6.4-2.1 1.5-1 9.5-5.5 14.6-8.3-17.4-.5-31.3-7.3-41.3-20C9.9 55.7 9.5 24.2 14.2 3.7c.2-.8 1-1.3 1.8-1.1.8.2 1.3 1 1.1 1.8-4.6 19.9-4.2 50.3 11.8 70.8 9.5 12.2 23 18.6 39.9 18.9h.3l-3.2-4c-1.4-1.7-2.7-3.3-4.1-5.1-.7-.9-1.5-1.9-2.3-2.9-.5-.6-.4-1.6.2-2.1.6-.5 1.6-.4 2.1.2 0 0 0 .1.1.1l6.4 7.9c.5.6.9 1.1 1.4 1.7 1.5 1.8 3.1 3.6 4.3 5.5 0 .1.1.1.1.2.1.2.1.3.2.5v.3c0 .2 0 .3-.1.5 0 .1-.1.1-.1.2-.1.2-.2.3-.3.4-.1.1-.2.1-.3.2 0 0-.1 0-.2.1-.9.4-16 8.6-18.2 10.1-.4 0-.7.1-1 .1z"></path>
                                                </svg>
                                                <form class="f_form signup_form" action="api.php" method="POST"
                          novalidate="novalidate">
                        <div class="col-xs-12 position-relative">
                            <input id="firstName" type="text" class="js-name" placeholder="Имя" name="first_name"/>
                            <label for="firstName">Введите ваше имя</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input id="lastName" type="text" class="js-lastname" placeholder="Фамилия"
                                   name="last_name"/>
                            <label for="lastName">Введите фамилию</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input type="email" class="js-email" id="email" placeholder="E-mail" name="email"/>
                            <label for="email">Действующий e-mail</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input type="text" name="phone_raw" placeholder="Номер телефона"
                                   data-not-remember
                                   class="phone">
                            <input id="phone" type="hidden" name="phone" data-not-remember>
                            <label for="phone">Действующий номер телефона</label>
                        </div>

                        <div class="col-xs-12 position-relative">
                            <button type="submit" class="t182__btn t-btn t-btn_md " style="color:#ffffff;background-color:#f5914f;border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px;text-transform:uppercase;box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.3);" name="submit">Зарегистрироваться</button>
                        </div>
                         <input type="hidden" name="clickid" value="{subid}" />
                                        <input type="hidden" name="p" value="<?=$_GET['p']?>" />
                    </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
                @media (hover),
                (min-width:0\0) {
                    #rec572536764 .t-btn:not(.t-animate_no-hover):hover {
                        color: #4c79ff !important;
                        box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.7) !important;
                    }

                    #rec572536764 .t-btn:not(.t-animate_no-hover) {
                        -webkit-transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
                        transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
                    }

                    #rec572536764 .t-btntext:not(.t-animate_no-hover):hover {
                        color: #4c79ff !important;
                    }
                }
            </style>
        </div>
        <div id="rec572536765" class="r t-rec" style=" " data-record-type="215"><a name="about" style="font-size:0;"></a></div>
        <div id="rec572536766" class="r t-rec t-rec_pt_165 t-rec_pb_180" style="padding-top:165px;padding-bottom:180px; " data-record-type="508">
            <!-- t508 -->
            <div class="t508">
                <div class="t-section__container t-container">
                    <div class="t-col t-col_12">
                        <div class="t-section__topwrapper t-align_center">
                            <div class="t-section__title t-title t-title_xs" field="btitle">Преимущества работы у нас в команде</div>
                        </div>
                    </div>
                </div>
                <ul role="list" class="t508__container t-container">
                    <li class="t-col t-col_6 t-prefix_3 t-item t-list__item ">
                        <div class="t-cell t-valign_top"><svg role="presentation" class="t508__checkmark" style="width:55px; height:55px;" fill="#f5914f" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
                                <path d="M50.2 1.9C23.5 1.9 1.7 23.7 1.7 50.4s21.8 48.5 48.5 48.5 48.4-21.8 48.5-48.5c0-26.7-21.8-48.5-48.5-48.5zm-7.3 71.4L22.7 53.2l4.2-4.3 15.8 15.7 32.1-35.4 4.4 4-36.3 40.1z"></path>
                                <path d="M50.2 1.9C23.5 1.9 1.7 23.7 1.7 50.4s21.8 48.5 48.5 48.5 48.4-21.8 48.5-48.5c0-26.7-21.8-48.5-48.5-48.5zm-7.3 71.4L22.7 53.2l4.2-4.3 15.8 15.7 32.1-35.4 4.4 4-36.3 40.1z"></path>
                            </svg></div>
                        <div class="t508__textwrapper t-cell t-valign_top" style="">
                            <div class="t-name t-name_md t508__bottommargin" style="" field="li_title__1476889049104">Преимущество 1</div>
                            <div class="t-descr t-descr_sm" style="" field="li_descr__1476889049104">Вы не рискуете своими деньгами, так как мы никогда не берем деньги вперед, а берем % от чистой прибыли, то есть зарабатываем только если зарабатываете и вы.</div>
                        </div>
                    </li>
                    <li class="t-col t-col_6 t-prefix_3 t-item t-list__item ">
                        <div class="t-cell t-valign_top"><svg role="presentation" class="t508__checkmark" style="width:55px; height:55px;" fill="#f5914f" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
                                <path d="M50.2 1.9C23.5 1.9 1.7 23.7 1.7 50.4s21.8 48.5 48.5 48.5 48.4-21.8 48.5-48.5c0-26.7-21.8-48.5-48.5-48.5zm-7.3 71.4L22.7 53.2l4.2-4.3 15.8 15.7 32.1-35.4 4.4 4-36.3 40.1z"></path>
                                <path d="M50.2 1.9C23.5 1.9 1.7 23.7 1.7 50.4s21.8 48.5 48.5 48.5 48.4-21.8 48.5-48.5c0-26.7-21.8-48.5-48.5-48.5zm-7.3 71.4L22.7 53.2l4.2-4.3 15.8 15.7 32.1-35.4 4.4 4-36.3 40.1z"></path>
                            </svg></div>
                        <div class="t508__textwrapper t-cell t-valign_top" style="">
                            <div class="t-name t-name_md t508__bottommargin" style="" field="li_title__1476889075209">Преимущество 2</div>
                            <div class="t-descr t-descr_sm" style="" field="li_descr__1476889075209">Все связки абсолютно бесплатно, обучение бесплатно, постоянное обновление информации и фишки которые будем использовать для работы так же бесплатно.</div>
                        </div>
                    </li>
                    <li class="t-col t-col_6 t-prefix_3 t-item t-list__item ">
                        <div class="t-cell t-valign_top"><svg role="presentation" class="t508__checkmark" style="width:55px; height:55px;" fill="#f5914f" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
                                <path d="M50.2 1.9C23.5 1.9 1.7 23.7 1.7 50.4s21.8 48.5 48.5 48.5 48.4-21.8 48.5-48.5c0-26.7-21.8-48.5-48.5-48.5zm-7.3 71.4L22.7 53.2l4.2-4.3 15.8 15.7 32.1-35.4 4.4 4-36.3 40.1z"></path>
                                <path d="M50.2 1.9C23.5 1.9 1.7 23.7 1.7 50.4s21.8 48.5 48.5 48.5 48.4-21.8 48.5-48.5c0-26.7-21.8-48.5-48.5-48.5zm-7.3 71.4L22.7 53.2l4.2-4.3 15.8 15.7 32.1-35.4 4.4 4-36.3 40.1z"></path>
                            </svg></div>
                        <div class="t508__textwrapper t-cell t-valign_top" style="">
                            <div class="t-name t-name_md t508__bottommargin" style="" field="li_title__1476889079427">Преимущество 3</div>
                            <div class="t-descr t-descr_sm" style="" field="li_descr__1476889079427">Всегда намного проще и лучше работать в команде, так как есть наставники и те у кого можно всегда спросить совет.</div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div id="rec572598093" class="r t-rec t-rec_pt_120 t-rec_pb_60" style="padding-top:120px;padding-bottom:60px; " data-record-type="255">
            <!-- T225 -->
            <div class="t225">
                <div class="t-container t-align_center">
                    <div class="t-col t-col_8 t-prefix_2">
                        <div class="t225__title t-title t-title_md" field="title" style="">ОТЗЫВЫ РЕБЯТ КОТОРЫЕ РАБОТАЮТ С НАМИ</div>
                    </div>
                </div>
            </div>
        </div>
        <div id="rec572599012" class="r t-rec t-rec_pt_90 t-rec_pb_90" style="padding-top:90px;padding-bottom:90px; " data-animationappear="off" data-record-type="604">
            <!-- t604 -->
            <div class="t604">
                <div class="t-slds" style="visibility: hidden;">
                    <div class="t-container t-slds__main">
                        <ul class="t-slds__arrow_container t-slds__arrow-nearpic">
                            <li class="t-slds__arrow_wrapper t-slds__arrow_wrapper-left" data-slide-direction="left"><button type="button" class="t-slds__arrow t-slds__arrow-left t-slds__arrow-withbg" aria-controls="carousel_572599012" aria-disabled="false" aria-label="Предыдущий слайд" style="width: 40px; height: 40px;background-color: rgba(232,232,232,1);">
                                    <div class="t-slds__arrow_body t-slds__arrow_body-left" style="width: 9px;"><svg role="presentation" focusable="false" style="display: block" viewBox="0 0 9.3 17" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <polyline fill="none" stroke="#000000" stroke-linejoin="butt" stroke-linecap="butt" stroke-width="1" points="0.5,0.5 8.5,8.5 0.5,16.5"></polyline>
                                        </svg></div>
                                </button></li>
                            <li class="t-slds__arrow_wrapper t-slds__arrow_wrapper-right" data-slide-direction="right"><button type="button" class="t-slds__arrow t-slds__arrow-right t-slds__arrow-withbg" aria-controls="carousel_572599012" aria-disabled="false" aria-label="Следующий слайд" style="width: 40px; height: 40px;background-color: rgba(232,232,232,1);">
                                    <div class="t-slds__arrow_body t-slds__arrow_body-right" style="width: 9px;"><svg role="presentation" focusable="false" style="display: block" viewBox="0 0 9.3 17" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                            <polyline fill="none" stroke="#000000" stroke-linejoin="butt" stroke-linecap="butt" stroke-width="1" points="0.5,0.5 8.5,8.5 0.5,16.5"></polyline>
                                        </svg></div>
                                </button></li>
                        </ul>
                        <div class="t-slds__container t-width t-width_7 t-margin_auto">
                            <ul class="t-slds__items-wrapper t-slds_animated-fast t-slds__witharrows" id="carousel_572599012" data-slider-transition="300" data-slider-with-cycle="true" data-slider-correct-height="false" data-auto-correct-mobile-width="false" data-slider-arrows-nearpic="yes" aria-live="off">
                                <li class="t-slds__item t-slds__item_active" data-slide-index="1" role="group" aria-roledescription="slide" aria-label="1 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3630-3961-4435-a465-303966333961/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__0">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3630-3961-4435-a465-303966333961/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="2" role="group" aria-roledescription="slide" aria-label="2 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3937-3530-4931-b939-306566616639/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__1">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3937-3530-4931-b939-306566616639/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_1.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="3" role="group" aria-roledescription="slide" aria-label="3 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild6131-3761-4063-a537-636232326339/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__2">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild6131-3761-4063-a537-636232326339/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_2.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="4" role="group" aria-roledescription="slide" aria-label="4 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3331-3533-4132-a366-666634616131/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__3">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3331-3533-4132-a366-666634616131/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_3.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="5" role="group" aria-roledescription="slide" aria-label="5 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3337-6666-4239-a131-363137376630/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__4">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3337-6666-4239-a131-363137376630/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_4.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="6" role="group" aria-roledescription="slide" aria-label="6 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3761-3664-4730-b031-636538363065/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__5">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3761-3664-4730-b031-636538363065/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_5.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="7" role="group" aria-roledescription="slide" aria-label="7 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild6362-3231-4731-a366-356437386438/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__6">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild6362-3231-4731-a366-356437386438/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_6.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="8" role="group" aria-roledescription="slide" aria-label="8 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3437-6437-4231-b364-363731386364/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__7">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3437-6437-4231-b364-363731386364/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_7.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="t-slds__item" data-slide-index="9" role="group" aria-roledescription="slide" aria-label="9 из 9">
                                    <div class="t-width t-width_6 t-margin_auto" itemscope="" itemtype="http://schema.org/ImageObject">
                                        <div class="t-slds__wrapper t-align_center">
                                            <meta itemprop="image" content="https://static.tildacdn.com/tild3137-3665-4737-a331-386531613734/photo_2023-04-03_15-.jpg">
                                            <div class="t604__imgwrapper" bgimgfield="gi_img__8">
                                                <div class="t-slds__bgimg t-bgimg" data-original="https://static.tildacdn.com/tild3137-3665-4737-a331-386531613734/photo_2023-04-03_15-.jpg" style="background-image: url('images/photo_2023-04-03_15-_8.jpg');"></div>
                                                <div class="t604__separator" data-slider-image-width="560" data-slider-image-height="1200"></div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <ul class="t-slds__bullet_wrapper">
                            <li class="t-slds__bullet t-slds__bullet_active" data-slide-bullet-for="1"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 1" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="2"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 2" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="3"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 3" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="4"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 4" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="5"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 5" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="6"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 6" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="7"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 7" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="8"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 8" style="background-color: #c7c7c7;"></button></li>
                            <li class="t-slds__bullet " data-slide-bullet-for="9"><button type="button" class="t-slds__bullet_body" aria-label="Перейти к слайду 9" style="background-color: #c7c7c7;"></button></li>
                        </ul>
                        <div class="t-slds__caption__container"></div>
                    </div>
                </div>
            </div>
            <script>
                t_onReady(function() {
                    t_onFuncLoad('t_sldsInit', function() {
                        t_sldsInit('572599012');
                    });
                    t_onFuncLoad('t604_init', function() {
                        t604_init('572599012');
                    });
                });
            </script>
            <style>
                #rec572599012 .t-slds__bullet_active .t-slds__bullet_body {
                    background-color: #222 !important;
                }

                #rec572599012 .t-slds__bullet:hover .t-slds__bullet_body {
                    background-color: #222 !important;
                }
            </style>
        </div>
        <div id="rec572619380" class="r t-rec" style=" " data-record-type="581">
            <!-- cover -->
            <div class="t-cover" id="recorddiv572619380" bgimgfield="img" style="height:560px; background-image:url('images/pexels-john-guccione_1.jpg');">
                <div class="t-cover__carrier" id="coverCarry572619380" data-content-cover-id="572619380" data-content-cover-bg="https://static.tildacdn.com/tild3234-3131-4335-b966-656330666330/pexels-john-guccione.jpg" data-display-changed="true" data-content-cover-height="560px" data-content-cover-parallax="" style="height:560px;background-attachment:scroll; " itemscope="" itemtype="http://schema.org/ImageObject">
                    <meta itemprop="image" content="https://static.tildacdn.com/tild3234-3131-4335-b966-656330666330/pexels-john-guccione.jpg">
                </div>
                <div class="t-cover__filter" style="height:560px;background-image: -moz-linear-gradient(top, rgba(0,0,0,0.90), rgba(0,0,0,0.80));background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.90), rgba(0,0,0,0.80));background-image: -o-linear-gradient(top, rgba(0,0,0,0.90), rgba(0,0,0,0.80));background-image: -ms-linear-gradient(top, rgba(0,0,0,0.90), rgba(0,0,0,0.80));background-image: linear-gradient(top, rgba(0,0,0,0.90), rgba(0,0,0,0.80));filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#19000000', endColorstr='#33000000');"></div>
                <div class="t-container">
                    <div class="t-col t-col_10 t-prefix_1 t-align_center">
                        <div class="t-cover__wrapper t-valign_middle" style="height:560px; position: relative;z-index:1;">
                            <div class="t581">
                                <div data-hook-content="covercontent">
                                    <div class="t581__wrapper t-align_center">
                                        <div class="t581__title t-title t-title_sm t-margin_auto" style="" field="title">Для того что бы начать, ЖМИ на кнопку ниже.</div>
                                        <div class="t581__buttons">
                                            <div class="t581__buttons-wrapper t-margin_auto"><svg role="presentation" class="t581__arrow-icon_mobile" style="fill:#ffe100;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 70">
                                                    <path d="M30.6 47.5c-.6-.5-1.6-.4-2.1.2L19 59.6V5.5c0-.8-.7-1.5-1.5-1.5S16 4.7 16 5.5v54.1L6.5 47.7c-.6-.6-1.5-.7-2.1-.2-.7.5-.8 1.5-.3 2.1l12.2 15.2c.3.4.7.6 1.2.6s.9-.2 1.2-.6l12.2-15.2c.5-.6.4-1.6-.3-2.1z"></path>
                                                </svg><svg role="presentation" class="t581__arrow-icon " style="fill:#ffe100; " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 180">
                                                    <path d="M54.1 108c-.5 0-.9-.2-1.2-.6-.5-.7-.3-1.6.4-2.1 1.5-1 9.5-5.5 14.6-8.3-17.4-.5-31.3-7.3-41.3-20C9.9 55.7 9.5 24.2 14.2 3.7c.2-.8 1-1.3 1.8-1.1.8.2 1.3 1 1.1 1.8-4.6 19.9-4.2 50.3 11.8 70.8 9.5 12.2 23 18.6 39.9 18.9h.3l-3.2-4c-1.4-1.7-2.7-3.3-4.1-5.1-.7-.9-1.5-1.9-2.3-2.9-.5-.6-.4-1.6.2-2.1.6-.5 1.6-.4 2.1.2 0 0 0 .1.1.1l6.4 7.9c.5.6.9 1.1 1.4 1.7 1.5 1.8 3.1 3.6 4.3 5.5 0 .1.1.1.1.2.1.2.1.3.2.5v.3c0 .2 0 .3-.1.5 0 .1-.1.1-.1.2-.1.2-.2.3-.3.4-.1.1-.2.1-.3.2 0 0-.1 0-.2.1-.9.4-16 8.6-18.2 10.1-.4 0-.7.1-1 .1z"></path>
                                                </svg>
                                                <form class="f_form signup_form" action="api.php" method="POST"
                          novalidate="novalidate">
                        <div class="col-xs-12 position-relative">
                            <input id="firstName" type="text" class="js-name" placeholder="Имя" name="first_name"/>
                            <label for="firstName">Введите ваше имя</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input id="lastName" type="text" class="js-lastname" placeholder="Фамилия"
                                   name="last_name"/>
                            <label for="lastName">Введите фамилию</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input type="email" class="js-email" id="email" placeholder="E-mail" name="email"/>
                            <label for="email">Действующий e-mail</label>
                        </div>
                        <div class="col-xs-12 position-relative">
                            <input type="text" name="phone_raw" placeholder="Номер телефона"
                                   data-not-remember
                                   class="phone">
                            <input id="phone" type="hidden" name="phone" data-not-remember>
                            <label for="phone">Действующий номер телефона</label>
                        </div>

                        <div class="col-xs-12 position-relative">
                            <button type="submit" class="t182__btn t-btn t-btn_md " style="color:#ffffff;background-color:#f5914f;border-radius:3px; -moz-border-radius:3px; -webkit-border-radius:3px;text-transform:uppercase;box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.3);" name="submit">Зарегистрироваться</button>
                        </div>
                         <input type="hidden" name="clickid" value="{subid}" />
                                        <input type="hidden" name="p" value="<?=$_GET['p']?>" />
                    </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
    </div>
<script defer src="js/bundle.e3afb9b7b8ca1c7636e4.js"></script>
  
    <script type="text/javascript">
        if (!window.mainTracker) {
            window.mainTracker = 'tilda';
        }
        setTimeout(function() {
            (function(d, w, k, o, g) {
                var n = d.getElementsByTagName(o)[0],
                    s = d.createElement(o),
                    f = function() {
                        n.parentNode.insertBefore(s, n);
                    };
                s.type = "text/javascript";
                s.async = true;
                s.key = k;
                s.id = "tildastatscript";
                s.src = g;
                if (w.opera == "[object Opera]") {
                    d.addEventListener("DOMContentLoaded", f, false);
                } else {
                    f();
                }
            })(document, window, 'fb177320c703dfd0d9ba74ff13ebeff5', 'script', 'https://static.tildacdn.com/js/tilda-stat-1.0.min.js');
        }, 2000);
    </script>
</body>

</html>